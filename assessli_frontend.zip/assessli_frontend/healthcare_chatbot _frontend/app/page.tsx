import Chat from "@/components/chat";
// import ChatTest from "@/components/test"

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-between">
      {/* <ChatTest /> */}
      <Chat />
    </main>
  );
}
